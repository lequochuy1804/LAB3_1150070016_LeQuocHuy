package Tuan3.Dulieu;
import java.sql.*;
import java.util.Set;
import javax.swing.table.DefaultTableModel;
public final class LichSu {
    private LichSu() {
    }
    public static void insert(String algorithm, String operation, int length, boolean success) throws SQLException {
        if (algorithm == null || algorithm.isBlank() || algorithm.length() > 30 || length < 0
                || !Set.of("ENCRYPT", "DECRYPT", "SIGN", "VERIFY").contains(operation)) {
            throw new IllegalArgumentException("Thông tin lịch sử không hợp lệ.");
        }
        String sql = "INSERT INTO dbo.History(Algorithm, Operation, InputLength, Success) VALUES (?, ?, ?, ?)";
        try (Connection connection = KetNoi.moKetNoi(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setNString(1, algorithm);
            statement.setNString(2, operation);
            statement.setInt(3, length);
            statement.setBoolean(4, success);
            statement.executeUpdate();
        }
    }
    public static String tryInsert(String algorithm, String operation, int length, boolean success) {
        if (!KetNoi.daKetNoi()) return "(Chưa kết nối SQL Server - chưa lưu lịch sử)";
        try {
            insert(algorithm, operation, length, success);
            return "(Đã lưu lịch sử SQL Server)";
        } catch (SQLException ex) {
            return "(Không lưu được lịch sử SQL Server)";
        }
    }
    public static DefaultTableModel emptyModel() {
        return new DefaultTableModel(new Object[]{"Id", "Thời gian", "Thuật toán", "Thao tác", "Độ dài vào", "Thành công"}, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }
    public static DefaultTableModel loadLatest(int top) throws SQLException {
        if (top < 1 || top > 1000) throw new IllegalArgumentException("Số dòng phải từ 1 đến 1000.");
        DefaultTableModel model = emptyModel();
        String sql = "SELECT TOP (?) Id, CreatedAt, Algorithm, Operation, InputLength, Success FROM dbo.History ORDER BY Id DESC";
        try (Connection connection = KetNoi.moKetNoi(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, top);
            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) model.addRow(new Object[]{rs.getLong(1), rs.getTimestamp(2), rs.getString(3),
                    rs.getString(4), rs.getInt(5), rs.getBoolean(6) ? "Có" : "Không"});
            }
        }
        return model;
    }
}
