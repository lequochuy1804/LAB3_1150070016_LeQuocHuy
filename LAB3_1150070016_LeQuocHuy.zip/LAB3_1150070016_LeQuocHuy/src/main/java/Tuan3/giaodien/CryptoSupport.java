package Tuan3.giaodien;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.*;
import java.security.spec.*;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;
public final class CryptoSupport {
    private static final SecureRandom RANDOM = new SecureRandom();
    private CryptoSupport() {
    }
    public static byte[] randomBytes(int length) {
        byte[] result = new byte[length];
        RANDOM.nextBytes(result);
        return result;
    }
    public static String b64(byte[] data) {
        return Base64.getEncoder().encodeToString(data);
    }
    public static byte[] unb64(String text) {
        if (text == null) throw new IllegalArgumentException("Chưa có dữ liệu Base64.");
        try {
            return Base64.getDecoder().decode(text.replaceAll("\\s+", ""));
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Dữ liệu không phải Base64 hợp lệ.");
        }
    }
    public static byte[] utf8(String text) {
        return text.getBytes(StandardCharsets.UTF_8);
    }
    public static String text(byte[] data) throws java.nio.charset.CharacterCodingException {
        return StandardCharsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(data)).toString();
    }
    public static byte[] concat(byte[]... parts) {
        int length = 0;
        for (byte[] part : parts) length = Math.addExact(length, part.length);
        byte[] result = new byte[length];
        int offset = 0;
        for (byte[] part : parts) {
            System.arraycopy(part, 0, result, offset, part.length);
            offset += part.length;
        }
        return result;
    }
    public static byte[] slice(byte[] data, int from, int to) {
        if (from < 0 || to > data.length || from > to) throw new IllegalArgumentException("Bản mã quá ngắn hoặc bị hỏng.");
        return Arrays.copyOfRange(data, from, to);
    }
    private static byte[] gcm(int mode, byte[] key, byte[] nonce, byte[] data) throws GeneralSecurityException {
        if (key.length != 32 || nonce.length != 12) throw new IllegalArgumentException("AES-256-GCM cần khóa 32 byte và nonce 12 byte.");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(mode, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, nonce));
        return cipher.doFinal(data);
    }
    public static byte[] gcmEncrypt(byte[] key, byte[] nonce, byte[] data) throws GeneralSecurityException {
        return gcm(Cipher.ENCRYPT_MODE, key, nonce, data);
    }
    public static byte[] gcmDecrypt(byte[] key, byte[] nonce, byte[] data) throws GeneralSecurityException {
        return gcm(Cipher.DECRYPT_MODE, key, nonce, data);
    }
    public static byte[] hkdf(byte[] secret, byte[] salt, byte[] info) throws GeneralSecurityException {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(salt.length == 0 ? new byte[32] : salt, "HmacSHA256"));
        byte[] prk = mac.doFinal(secret);
        try {
            mac.init(new SecretKeySpec(prk, "HmacSHA256"));
            mac.update(info);
            mac.update((byte)1);
            return mac.doFinal();
        } finally {
            Arrays.fill(prk, (byte)0);
        }
    }
    public static OAEPParameterSpec oaep() {
        return new OAEPParameterSpec("SHA-256", "MGF1", MGF1ParameterSpec.SHA256, PSource.PSpecified.DEFAULT);
    }
    public static KeyPair newRsa(int bits) throws GeneralSecurityException {
        if (bits != 2048 && bits != 3072) throw new IllegalArgumentException("Chỉ chọn RSA 2048 hoặc 3072 bit.");
        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(bits, RANDOM);
        return generator.generateKeyPair();
    }
    public static KeyPair newEc() throws GeneralSecurityException {
        KeyPairGenerator generator = KeyPairGenerator.getInstance("EC");
        generator.initialize(new ECGenParameterSpec("secp256r1"), RANDOM);
        return generator.generateKeyPair();
    }
    private static void requireP256(java.security.spec.ECParameterSpec actual) throws GeneralSecurityException {
        AlgorithmParameters algorithm = AlgorithmParameters.getInstance("EC");
        algorithm.init(new ECGenParameterSpec("secp256r1"));
        ECParameterSpec expected = algorithm.getParameterSpec(ECParameterSpec.class);
        if (!actual.getCurve().equals(expected.getCurve()) || !actual.getGenerator().equals(expected.getGenerator())
                || !actual.getOrder().equals(expected.getOrder()) || actual.getCofactor() != expected.getCofactor()) {
            throw new InvalidKeyException("Khóa ECC phải dùng đường cong secp256r1.");
        }
    }
    public static PublicKey ecPublic(byte[] encoded) throws GeneralSecurityException {
        PublicKey key = KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(encoded));
        requireP256(((ECPublicKey)key).getParams());
        return key;
    }
    public static KeyPair readEcKeys(String publicText, String privateText) throws GeneralSecurityException {
        PublicKey pub = ecPublic(unb64(publicText));
        PrivateKey pri = null;
        if (privateText != null && !privateText.isBlank()) {
            pri = KeyFactory.getInstance("EC").generatePrivate(new PKCS8EncodedKeySpec(unb64(privateText)));
            requireP256(((ECPrivateKey)pri).getParams());
            byte[] challenge = randomBytes(32);
            Signature signature = Signature.getInstance("SHA256withECDSA");
            signature.initSign(pri);
            signature.update(challenge);
            byte[] signed = signature.sign();
            signature.initVerify(pub);
            signature.update(challenge);
            if (!signature.verify(signed)) throw new InvalidKeyException("Khóa công khai và khóa riêng không cùng cặp.");
        }
        return new KeyPair(pub, pri);
    }
    public static KeyPair readRsaKeys(String publicText, String privateText, int requiredBits) throws GeneralSecurityException {
        KeyFactory factory = KeyFactory.getInstance("RSA");
        RSAPublicKey pub = (RSAPublicKey)factory.generatePublic(new X509EncodedKeySpec(unb64(publicText)));
        int bits = pub.getModulus().bitLength();
        if ((bits != 2048 && bits != 3072) || (requiredBits != 0 && bits != requiredBits)) {
            throw new InvalidKeyException(requiredBits == 2048 ? "Hệ mã lai cần khóa RSA-2048." : "Khóa RSA phải có 2048 hoặc 3072 bit.");
        }
        PrivateKey pri = null;
        if (privateText != null && !privateText.isBlank()) {
            pri = factory.generatePrivate(new PKCS8EncodedKeySpec(unb64(privateText)));
            if (!pub.getModulus().equals(((RSAPrivateKey)pri).getModulus())) throw new InvalidKeyException("Khóa công khai và khóa riêng không cùng cặp.");
        }
        return new KeyPair(pub, pri);
    }
    public static String toKeyFile(String publicText, String privateText) {
        if (publicText == null || publicText.isBlank()) throw new IllegalArgumentException("Chưa có khóa để lưu.");
        return "PUBLIC=" + publicText.replaceAll("\\s+", "") + "\nPRIVATE="
                + (privateText == null ? "" : privateText.replaceAll("\\s+", "")) + "\n";
    }
    public static String[] fromKeyFile(String content) {
        String pub = null, pri = "";
        boolean privateFound = false;
        for (String line : content.split("\\R")) {
            line = line.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("PUBLIC=") && pub == null) pub = line.substring(7).trim();
            else if (line.startsWith("PRIVATE=") && !privateFound) {
                pri = line.substring(8).trim();
                privateFound = true;
            } else throw new IllegalArgumentException("Tệp khóa không đúng định dạng PUBLIC=/PRIVATE=.");
        }
        if (pub == null || pub.isEmpty()) throw new IllegalArgumentException("Tệp khóa phải có dòng PUBLIC=...");
        unb64(pub);
        if (!pri.isEmpty()) unb64(pri);
        return new String[]{pub, pri};
    }
}
