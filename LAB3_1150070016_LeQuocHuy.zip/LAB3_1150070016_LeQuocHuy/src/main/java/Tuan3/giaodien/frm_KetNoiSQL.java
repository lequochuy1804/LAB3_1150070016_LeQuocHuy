package Tuan3.giaodien;
public class frm_KetNoiSQL extends javax.swing.JFrame {
    public frm_KetNoiSQL() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints grid;
        setDefaultCloseOperation(2);
        setTitle("Kết nối Microsoft SQL Server");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("KẾT NỐI MICROSOFT SQL SERVER");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        lbl_title.setPreferredSize(new java.awt.Dimension(450, 34));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 2;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(20, 20, 6, 20);
        panel_main.add(lbl_title, grid);
        lbl_txt_server = new javax.swing.JLabel();
        lbl_txt_server.setText("Server:");
        lbl_txt_server.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_txt_server.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_txt_server, grid);
        panel_txt_server = new javax.swing.JPanel();
        panel_txt_server.setBackground(new java.awt.Color(214, 217, 223));
        panel_txt_server.setLayout(new java.awt.GridBagLayout());
        txt_server = new javax.swing.JTextField();
        txt_server.setText("127.0.0.1");
        txt_server.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_server.setPreferredSize(new java.awt.Dimension(320, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_txt_server.add(txt_server, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_txt_server, grid);
        lbl_txt_port = new javax.swing.JLabel();
        lbl_txt_port.setText("Port:");
        lbl_txt_port.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_txt_port.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_txt_port, grid);
        panel_txt_port = new javax.swing.JPanel();
        panel_txt_port.setBackground(new java.awt.Color(214, 217, 223));
        panel_txt_port.setLayout(new java.awt.GridBagLayout());
        txt_port = new javax.swing.JTextField();
        txt_port.setText("14333");
        txt_port.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_port.setPreferredSize(new java.awt.Dimension(120, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_txt_port.add(txt_port, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_txt_port, grid);
        lbl_txt_database = new javax.swing.JLabel();
        lbl_txt_database.setText("Database:");
        lbl_txt_database.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_txt_database.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_txt_database, grid);
        panel_txt_database = new javax.swing.JPanel();
        panel_txt_database.setBackground(new java.awt.Color(214, 217, 223));
        panel_txt_database.setLayout(new java.awt.GridBagLayout());
        txt_database = new javax.swing.JTextField();
        txt_database.setText("LAB3_MaHoaKhoaCongKhai");
        txt_database.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_database.setPreferredSize(new java.awt.Dimension(320, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_txt_database.add(txt_database, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_txt_database, grid);
        lbl_txt_user = new javax.swing.JLabel();
        lbl_txt_user.setText("User:");
        lbl_txt_user.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_txt_user.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_txt_user, grid);
        panel_txt_user = new javax.swing.JPanel();
        panel_txt_user.setBackground(new java.awt.Color(214, 217, 223));
        panel_txt_user.setLayout(new java.awt.GridBagLayout());
        txt_user = new javax.swing.JTextField();
        txt_user.setText("sa");
        txt_user.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_user.setPreferredSize(new java.awt.Dimension(320, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_txt_user.add(txt_user, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_txt_user, grid);
        lbl_txt_password = new javax.swing.JLabel();
        lbl_txt_password.setText("Password:");
        lbl_txt_password.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_txt_password.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 5;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_txt_password, grid);
        panel_txt_password = new javax.swing.JPanel();
        panel_txt_password.setBackground(new java.awt.Color(214, 217, 223));
        panel_txt_password.setLayout(new java.awt.GridBagLayout());
        txt_password = new javax.swing.JPasswordField();
        txt_password.setText("");
        txt_password.setFont(new java.awt.Font("Segoe UI", 0, 12));
        txt_password.setPreferredSize(new java.awt.Dimension(320, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_txt_password.add(txt_password, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 5;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(panel_txt_password, grid);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_test = new javax.swing.JButton();
        btn_test.setText("Test Connection");
        btn_test.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_test.setPreferredSize(new java.awt.Dimension(150, 30));
        btn_test.addActionListener(evt -> btn_testActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_test, grid);
        btn_history = new javax.swing.JButton();
        btn_history.setText("Xem lịch sử");
        btn_history.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_history.setPreferredSize(new java.awt.Dimension(130, 30));
        btn_history.addActionListener(evt -> btn_historyActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_history, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 6;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(panel_actions, grid);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Chưa kết nối.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(450, 36));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 7;
        grid.gridwidth = 2;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 16, 20);
        panel_main.add(lbl_status, grid);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }
    private void btn_testActionPerformed(java.awt.event.ActionEvent evt) {
        int port;
        try {
            port = Integer.parseInt(txt_port.getText().trim());
        } catch (NumberFormatException ex) {
            showError("Port phải là số nguyên từ 1 đến 65535.");
            return;
        }
        String server = txt_server.getText().trim();
        String database = txt_database.getText().trim();
        String user = txt_user.getText().trim();
        char[] password = txt_password.getPassword();
        runAsync(() -> {
            try {
                return Tuan3.Dulieu.KetNoi.kiemTra(server, port, database, user, new String(password));
            } finally {
                java.util.Arrays.fill(password, '\0');
            }
        }, result -> {
            txt_password.setText("");
            lbl_status.setText("<html>" + result + "</html>");
        });
    }
    private boolean processing;
    private void showError(String message) {
        lbl_status.setText("<html>" + message + "</html>");
        javax.swing.JOptionPane.showMessageDialog(this, message, "Thông báo", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    private void enableInputs(java.awt.Container container, boolean enabled) {
        for (java.awt.Component component : container.getComponents()) {
            if (component instanceof javax.swing.JButton || component instanceof javax.swing.text.JTextComponent) component.setEnabled(enabled);
            if (component instanceof java.awt.Container child) enableInputs(child, enabled);
        }
    }
    private <T> void runAsync(java.util.concurrent.Callable<T> work, java.util.function.Consumer<T> complete) {
        if (processing) return;
        processing = true;
        enableInputs(panel_main, false);
        lbl_status.setText("Đang xử lý...");
        new javax.swing.SwingWorker<T, Void>() {
            protected T doInBackground() throws Exception {
                return work.call();
            }
            protected void done() {
                try {
                    complete.accept(get());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    showError("Thao tác đã bị gián đoạn.");
                } catch (java.util.concurrent.ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    if (cause instanceof javax.crypto.AEADBadTagException) showError("Giải mã thất bại: sai Key hoặc bản mã bị sửa.");
                    else if (cause instanceof java.sql.SQLException) showError("Không thực hiện được thao tác SQL Server. Kiểm tra kết nối và quyền truy cập.");
                    else if (cause instanceof IllegalArgumentException) showError(cause.getMessage());
                    else showError("Xử lý thất bại: sai Key, IV hoặc dữ liệu bị hỏng.");
                } finally {
                    processing = false;
                    enableInputs(panel_main, true);
                }
            }
        }.execute();
    }
    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            java.awt.Toolkit.getDefaultToolkit().beep();
        }
        java.awt.EventQueue.invokeLater(() -> new frm_KetNoiSQL().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_txt_server;
    private javax.swing.JPanel panel_txt_server;
    private javax.swing.JTextField txt_server;
    private javax.swing.JLabel lbl_txt_port;
    private javax.swing.JPanel panel_txt_port;
    private javax.swing.JTextField txt_port;
    private javax.swing.JLabel lbl_txt_database;
    private javax.swing.JPanel panel_txt_database;
    private javax.swing.JTextField txt_database;
    private javax.swing.JLabel lbl_txt_user;
    private javax.swing.JPanel panel_txt_user;
    private javax.swing.JTextField txt_user;
    private javax.swing.JLabel lbl_txt_password;
    private javax.swing.JPanel panel_txt_password;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_test;
    private javax.swing.JButton btn_history;
    private javax.swing.JLabel lbl_status;
}
