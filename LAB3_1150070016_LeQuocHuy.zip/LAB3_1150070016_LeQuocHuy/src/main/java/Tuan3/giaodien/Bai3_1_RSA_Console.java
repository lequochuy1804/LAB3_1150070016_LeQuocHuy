package Tuan3.giaodien;
import java.util.Scanner;
public final class Bai3_1_RSA_Console {
    private Bai3_1_RSA_Console() {
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in, java.nio.charset.StandardCharsets.UTF_8);
        System.out.println("===== BAI 3.1 - RSA (OAEP, SHA-256) =====");
        try {
            System.out.print("Nhap kich thuoc khoa (2048 hoac 3072): ");
            int bits = Integer.parseInt(scanner.nextLine().trim());
            var rsa = new Bai3_2_RSA.RsaEngine();
            long start = System.nanoTime();
            rsa.generateKeys(bits);
            System.out.printf("Da tao cap khoa RSA-%d trong %.0f ms%n", bits, (System.nanoTime() - start) / 1e6);
            String publicKey = rsa.getPublicKeyBase64();
            System.out.println("Khoa cong khai (Base64, " + publicKey.length() + " ky tu): " + publicKey.substring(0, 40) + "...");
            System.out.println("Gioi han ban ro: " + rsa.maxPlaintextBytes() + " byte");
            System.out.print("Nhap ban ro: ");
            String plain = scanner.nextLine();
            String ciphertext = rsa.encrypt(plain);
            System.out.println("Ban ma (Base64, " + ciphertext.length() + " ky tu): " + ciphertext);
            String restored = rsa.decrypt(ciphertext);
            System.out.println("Giai ma: " + restored);
            System.out.println("Khoi phuc dung: " + plain.equals(restored));
        } catch (Exception ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }
}
