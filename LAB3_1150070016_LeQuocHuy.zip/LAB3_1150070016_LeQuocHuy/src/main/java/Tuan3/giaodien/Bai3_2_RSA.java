package Tuan3.giaodien;
public class Bai3_2_RSA extends javax.swing.JFrame {
    public Bai3_2_RSA() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints grid;
        setDefaultCloseOperation(2);
        setTitle("RSA Cipher");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("MẬT MÃ RSA (OAEP - SHA-256)");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        lbl_title.setPreferredSize(new java.awt.Dimension(600, 34));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 2;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(20, 20, 6, 20);
        panel_main.add(lbl_title, grid);
        lbl_1 = new javax.swing.JLabel();
        lbl_1.setText("Key size:");
        lbl_1.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_1.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_1, grid);
        panel_keys = new javax.swing.JPanel();
        panel_keys.setBackground(new java.awt.Color(214, 217, 223));
        panel_keys.setLayout(new java.awt.GridBagLayout());
        cbo_bits = new javax.swing.JComboBox<>();
        cbo_bits.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"2048", "3072"}));
        cbo_bits.setFont(new java.awt.Font("Segoe UI", 0, 12));
        cbo_bits.setPreferredSize(new java.awt.Dimension(110, 28));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_keys.add(cbo_bits, grid);
        btn_generate = new javax.swing.JButton();
        btn_generate.setText("Generate Keys");
        btn_generate.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_generate.setPreferredSize(new java.awt.Dimension(140, 30));
        btn_generate.addActionListener(evt -> btn_generateActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_keys.add(btn_generate, grid);
        lbl_keyinfo = new javax.swing.JLabel();
        lbl_keyinfo.setText("Chưa có khóa.");
        lbl_keyinfo.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_keyinfo.setPreferredSize(new java.awt.Dimension(330, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_keys.add(lbl_keyinfo, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(panel_keys, grid);
        lbl_2 = new javax.swing.JLabel();
        lbl_2.setText("Plaintext:");
        lbl_2.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_2.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_2, grid);
        scroll_txt_plaintext = new javax.swing.JScrollPane();
        scroll_txt_plaintext.setPreferredSize(new java.awt.Dimension(600, 60));
        txt_plaintext = new javax.swing.JTextArea();
        txt_plaintext.setLineWrap(true);
        txt_plaintext.setRows(2);
        txt_plaintext.setColumns(40);
        txt_plaintext.setEditable(true);
        txt_plaintext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_plaintext.setViewportView(txt_plaintext);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(scroll_txt_plaintext, grid);
        lbl_3 = new javax.swing.JLabel();
        lbl_3.setText("Ciphertext:");
        lbl_3.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_3.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_3, grid);
        scroll_txt_ciphertext = new javax.swing.JScrollPane();
        scroll_txt_ciphertext.setPreferredSize(new java.awt.Dimension(600, 110));
        txt_ciphertext = new javax.swing.JTextArea();
        txt_ciphertext.setLineWrap(true);
        txt_ciphertext.setRows(3);
        txt_ciphertext.setColumns(40);
        txt_ciphertext.setEditable(true);
        txt_ciphertext.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_ciphertext.setViewportView(txt_ciphertext);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(scroll_txt_ciphertext, grid);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_encrypt = new javax.swing.JButton();
        btn_encrypt.setText("Encrypt");
        btn_encrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_encrypt.setPreferredSize(new java.awt.Dimension(110, 30));
        btn_encrypt.addActionListener(evt -> btn_encryptActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_encrypt, grid);
        btn_decrypt = new javax.swing.JButton();
        btn_decrypt.setText("Decrypt");
        btn_decrypt.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_decrypt.setPreferredSize(new java.awt.Dimension(110, 30));
        btn_decrypt.addActionListener(evt -> btn_decryptActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_decrypt, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(panel_actions, grid);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Bấm Generate Keys để tạo cặp khóa.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(600, 36));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 5;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 14, 20);
        panel_main.add(lbl_status, grid);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_generateActionPerformed(java.awt.event.ActionEvent evt) {
        int bits = Integer.parseInt((String)cbo_bits.getSelectedItem());
        runAsync(() -> {
            long start = System.nanoTime();
            cipher.generateKeys(bits);
            return Math.round((System.nanoTime() - start) / 1e6);
        }, elapsed -> {
            lbl_keyinfo.setText("RSA-" + bits + ": tạo khóa " + elapsed + " ms, tối đa " + cipher.maxPlaintextBytes() + " byte");
            lbl_status.setText("Đã tạo cặp khóa RSA.");
        });
    }
    private void btn_encryptActionPerformed(java.awt.event.ActionEvent evt) {
        String input = txt_plaintext.getText();
        if (input.isEmpty()) {
            showError("Hãy nhập Plaintext trước khi mã hóa.");
            return;
        }
        executeOperation(() -> cipher.encrypt(input), "RSA", "ENCRYPT", input.length(), output -> {
            txt_ciphertext.setText(output);
            txt_ciphertext.setCaretPosition(0);
        });
    }
    private void btn_decryptActionPerformed(java.awt.event.ActionEvent evt) {
        String input = txt_ciphertext.getText();
        if (input.isEmpty()) {
            showError("Hãy nhập Ciphertext trước khi giải mã.");
            return;
        }
        executeOperation(() -> cipher.decrypt(input), "RSA", "DECRYPT", input.length(), output -> {
            txt_plaintext.setText(output);
            txt_plaintext.setCaretPosition(0);
        });
    }
    private boolean processing;
    private void showError(String text) {
        lbl_status.setText("<html>" + text + "</html>");
        javax.swing.JOptionPane.showMessageDialog(this, text, "Thông báo", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    private void enableInputs(java.awt.Container container, boolean enabled) {
        for (java.awt.Component component : container.getComponents()) {
            if (component instanceof javax.swing.JButton || component instanceof javax.swing.JComboBox
                    || component instanceof javax.swing.text.JTextComponent) component.setEnabled(enabled);
            if (component instanceof java.awt.Container child) enableInputs(child, enabled);
        }
    }
    private <T> void runAsync(java.util.concurrent.Callable<T> task, java.util.function.Consumer<T> completed) {
        if (processing) return;
        processing = true;
        enableInputs(panel_main, false);
        lbl_status.setText("Đang xử lý...");
        new javax.swing.SwingWorker<T, Void>() {
            protected T doInBackground() throws Exception {
                return task.call();
            }
            protected void done() {
                try {
                    completed.accept(get());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    showError("Thao tác đã bị gián đoạn.");
                } catch (java.util.concurrent.ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    showError(cause.getMessage() == null ? "Không thực hiện được thao tác." : cause.getMessage());
                } finally {
                    processing = false;
                    enableInputs(panel_main, true);
                }
            }
        }.execute();
    }
    private record OperationResult(String output, String error, String history) {
    }
    private void executeOperation(java.util.concurrent.Callable<String> task, String algorithm, String operation,
            int length, java.util.function.Consumer<String> completed) {
        runAsync(() -> {
            try {
                String output = task.call();
                boolean success = !operation.equals("VERIFY") || output.equals("VALID");
                return new OperationResult(output, null, Tuan3.Dulieu.LichSu.tryInsert(algorithm, operation, length, success));
            } catch (Exception ex) {
                String error = ex instanceof javax.crypto.AEADBadTagException || ex instanceof javax.crypto.BadPaddingException
                        ? "Giải mã THẤT BẠI: sai khóa riêng hoặc bản mã bị sửa."
                        : ex.getMessage() == null ? "Thao tác THẤT BẠI." : ex.getMessage();
                return new OperationResult(null, error, Tuan3.Dulieu.LichSu.tryInsert(algorithm, operation, length, false));
            }
        }, result -> {
            if (result.error() != null) {
                showError(result.error() + " " + result.history());
            } else {
                completed.accept(result.output());
                lbl_status.setText("<html>Đã thực hiện " + algorithm + " / " + operation + ". " + result.history() + "</html>");
            }
        });
    }
    private final RsaEngine cipher = new RsaEngine();
    public static final class RsaEngine {
        private volatile java.security.KeyPair keys;
        public void generateKeys(int bits) throws Exception {
            keys = CryptoSupport.newRsa(bits);
        }
        public int getBits() {
            return keys == null ? 0 : ((java.security.interfaces.RSAPublicKey)keys.getPublic()).getModulus().bitLength();
        }
        public int maxPlaintextBytes() {
            return getBits() / 8 - 66;
        }
        public String getPublicKeyBase64() {
            return keys == null ? "" : CryptoSupport.b64(keys.getPublic().getEncoded());
        }
        public String getPrivateKeyBase64() {
            return keys == null || keys.getPrivate() == null ? "" : CryptoSupport.b64(keys.getPrivate().getEncoded());
        }
        public void loadKeys(String publicText, String privateText) throws Exception {
            keys = CryptoSupport.readRsaKeys(publicText, privateText, 0);
        }
        public String encrypt(String text) throws Exception {
            java.security.KeyPair current = keys;
            if (current == null) throw new IllegalStateException("Chưa có khóa: bấm Generate Keys trước.");
            byte[] data = CryptoSupport.utf8(text);
            int bits = ((java.security.interfaces.RSAPublicKey)current.getPublic()).getModulus().bitLength();
            int limit = bits / 8 - 66;
            if (data.length > limit) throw new IllegalArgumentException("Bản rõ " + data.length + " byte vượt giới hạn "
                    + limit + " byte của RSA-" + bits + ". Văn bản dài hãy dùng RSA + AES (bài 3.4).");
            var cipher = javax.crypto.Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
            cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, current.getPublic(), CryptoSupport.oaep());
            return CryptoSupport.b64(cipher.doFinal(data));
        }
        public String decrypt(String text) throws Exception {
            java.security.KeyPair current = keys;
            if (current == null || current.getPrivate() == null) throw new IllegalStateException("Chưa có khóa riêng.");
            byte[] data = CryptoSupport.unb64(text);
            int bytes = (((java.security.interfaces.RSAPublicKey)current.getPublic()).getModulus().bitLength() + 7) / 8;
            if (data.length != bytes) throw new IllegalArgumentException("Độ dài bản mã RSA không hợp lệ.");
            var cipher = javax.crypto.Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
            cipher.init(javax.crypto.Cipher.DECRYPT_MODE, current.getPrivate(), CryptoSupport.oaep());
            return CryptoSupport.text(cipher.doFinal(data));
        }
    }
    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            java.awt.Toolkit.getDefaultToolkit().beep();
        }
        java.awt.EventQueue.invokeLater(() -> new Bai3_2_RSA().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_1;
    private javax.swing.JPanel panel_keys;
    private javax.swing.JComboBox<String> cbo_bits;
    private javax.swing.JButton btn_generate;
    private javax.swing.JLabel lbl_keyinfo;
    private javax.swing.JLabel lbl_2;
    private javax.swing.JScrollPane scroll_txt_plaintext;
    private javax.swing.JTextArea txt_plaintext;
    private javax.swing.JLabel lbl_3;
    private javax.swing.JScrollPane scroll_txt_ciphertext;
    private javax.swing.JTextArea txt_ciphertext;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_encrypt;
    private javax.swing.JButton btn_decrypt;
    private javax.swing.JLabel lbl_status;
}
