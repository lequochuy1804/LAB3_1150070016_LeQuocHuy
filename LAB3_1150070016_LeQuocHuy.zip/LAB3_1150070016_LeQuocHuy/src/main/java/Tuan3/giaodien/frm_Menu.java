package Tuan3.giaodien;
public class frm_Menu extends javax.swing.JFrame {
    public frm_Menu() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints grid;
        setDefaultCloseOperation(3);
        setTitle("LAB 3 - Mã hóa khóa công khai");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("LAB 3 - MÃ HÓA KHÓA CÔNG KHAI");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 20));
        lbl_title.setPreferredSize(new java.awt.Dimension(640, 38));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 3;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(20, 20, 8, 20);
        panel_main.add(lbl_title, grid);
        lbl_intro = new javax.swing.JLabel();
        lbl_intro.setText("Chọn một bài để mở form tương ứng (bài 3.1 chạy Bai3_1_RSA_Console.java bằng Run File):");
        lbl_intro.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_intro.setPreferredSize(new java.awt.Dimension(640, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 1;
        grid.gridwidth = 3;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 20);
        panel_main.add(lbl_intro, grid);
        btn_rsa = new javax.swing.JButton();
        btn_rsa.setText("3.2 RSA (Swing)");
        btn_rsa.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_rsa.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_rsa.addActionListener(evt -> btn_rsaActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 12, 0);
        panel_main.add(btn_rsa, grid);
        btn_ecc = new javax.swing.JButton();
        btn_ecc.setText("3.3 ECC");
        btn_ecc.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_ecc.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_ecc.addActionListener(evt -> btn_eccActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 12, 0);
        panel_main.add(btn_ecc, grid);
        btn_rsaaes = new javax.swing.JButton();
        btn_rsaaes.setText("3.4 RSA + AES");
        btn_rsaaes.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_rsaaes.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_rsaaes.addActionListener(evt -> btn_rsaaesActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 12, 20);
        panel_main.add(btn_rsaaes, grid);
        btn_signature = new javax.swing.JButton();
        btn_signature.setText("3.5 Chữ ký ECDSA");
        btn_signature.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_signature.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_signature.addActionListener(evt -> btn_signatureActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 18, 0);
        panel_main.add(btn_signature, grid);
        btn_sql = new javax.swing.JButton();
        btn_sql.setText("Kết nối SQL Server");
        btn_sql.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_sql.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_sql.addActionListener(evt -> btn_sqlActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 18, 0);
        panel_main.add(btn_sql, grid);
        btn_history = new javax.swing.JButton();
        btn_history.setText("Xem lịch sử");
        btn_history.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_history.setPreferredSize(new java.awt.Dimension(200, 30));
        btn_history.addActionListener(evt -> btn_historyActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 18, 20);
        panel_main.add(btn_history, grid);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_rsaActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai3_2_RSA().setVisible(true);
    }
    private void btn_eccActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai3_3_ECC().setVisible(true);
    }
    private void btn_rsaaesActionPerformed(java.awt.event.ActionEvent evt) {
        new Bai3_4_RSA_AES().setVisible(true);
    }
    private void btn_signatureActionPerformed(java.awt.event.ActionEvent evt) {
        new bai1nangcao().setVisible(true);
    }
    private void btn_sqlActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_KetNoiSQL().setVisible(true);
    }
    private void btn_historyActionPerformed(java.awt.event.ActionEvent evt) {
        new frm_LichSu().setVisible(true);
    }
    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            java.awt.Toolkit.getDefaultToolkit().beep();
        }
        java.awt.EventQueue.invokeLater(() -> new frm_Menu().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_intro;
    private javax.swing.JButton btn_rsa;
    private javax.swing.JButton btn_ecc;
    private javax.swing.JButton btn_rsaaes;
    private javax.swing.JButton btn_signature;
    private javax.swing.JButton btn_sql;
    private javax.swing.JButton btn_history;
}
