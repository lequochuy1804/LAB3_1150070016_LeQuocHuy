package Tuan3.giaodien;
public class bai1nangcao extends javax.swing.JFrame {
    public bai1nangcao() {
        initComponents();
        setLocationRelativeTo(null);
    }
    private void initComponents() {
        java.awt.GridBagConstraints grid;
        setDefaultCloseOperation(2);
        setTitle("ECDSA Signature");
        getContentPane().setLayout(new java.awt.BorderLayout());
        panel_main = new javax.swing.JPanel();
        panel_main.setBackground(new java.awt.Color(214, 217, 223));
        panel_main.setLayout(new java.awt.GridBagLayout());
        lbl_title = new javax.swing.JLabel();
        lbl_title.setText("CHỮ KÝ SỐ ECDSA (SHA256withECDSA)");
        lbl_title.setFont(new java.awt.Font("Segoe UI", 1, 18));
        lbl_title.setPreferredSize(new java.awt.Dimension(600, 34));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 2;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(20, 20, 6, 20);
        panel_main.add(lbl_title, grid);
        lbl_1 = new javax.swing.JLabel();
        lbl_1.setText("Public key:");
        lbl_1.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_1.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_1, grid);
        scroll_txt_public = new javax.swing.JScrollPane();
        scroll_txt_public.setPreferredSize(new java.awt.Dimension(600, 46));
        txt_public = new javax.swing.JTextArea();
        txt_public.setLineWrap(true);
        txt_public.setRows(2);
        txt_public.setColumns(40);
        txt_public.setEditable(false);
        txt_public.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_public.setViewportView(txt_public);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 1;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(scroll_txt_public, grid);
        lbl_2 = new javax.swing.JLabel();
        lbl_2.setText("Private key:");
        lbl_2.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_2.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_2, grid);
        scroll_txt_private = new javax.swing.JScrollPane();
        scroll_txt_private.setPreferredSize(new java.awt.Dimension(600, 46));
        txt_private = new javax.swing.JTextArea();
        txt_private.setLineWrap(true);
        txt_private.setRows(2);
        txt_private.setColumns(40);
        txt_private.setEditable(false);
        txt_private.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_private.setViewportView(txt_private);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 2;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(scroll_txt_private, grid);
        panel_keys = new javax.swing.JPanel();
        panel_keys.setBackground(new java.awt.Color(214, 217, 223));
        panel_keys.setLayout(new java.awt.GridBagLayout());
        btn_generate = new javax.swing.JButton();
        btn_generate.setText("Generate Keys");
        btn_generate.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_generate.setPreferredSize(new java.awt.Dimension(140, 30));
        btn_generate.addActionListener(evt -> btn_generateActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_keys.add(btn_generate, grid);
        btn_savekeys = new javax.swing.JButton();
        btn_savekeys.setText("Save Keys");
        btn_savekeys.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_savekeys.setPreferredSize(new java.awt.Dimension(120, 30));
        btn_savekeys.addActionListener(evt -> btn_savekeysActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_keys.add(btn_savekeys, grid);
        btn_loadkeys = new javax.swing.JButton();
        btn_loadkeys.setText("Load Keys");
        btn_loadkeys.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_loadkeys.setPreferredSize(new java.awt.Dimension(120, 30));
        btn_loadkeys.addActionListener(evt -> btn_loadkeysActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_keys.add(btn_loadkeys, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 3;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 14, 20);
        panel_main.add(panel_keys, grid);
        lbl_4 = new javax.swing.JLabel();
        lbl_4.setText("Message:");
        lbl_4.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_4.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 10, 14);
        panel_main.add(lbl_4, grid);
        scroll_txt_message = new javax.swing.JScrollPane();
        scroll_txt_message.setPreferredSize(new java.awt.Dimension(600, 56));
        txt_message = new javax.swing.JTextArea();
        txt_message.setLineWrap(true);
        txt_message.setRows(2);
        txt_message.setColumns(40);
        txt_message.setEditable(true);
        txt_message.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_message.setViewportView(txt_message);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 4;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 10, 20);
        panel_main.add(scroll_txt_message, grid);
        lbl_5 = new javax.swing.JLabel();
        lbl_5.setText("Signature:");
        lbl_5.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_5.setPreferredSize(new java.awt.Dimension(96, 22));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 5;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 20, 12, 14);
        panel_main.add(lbl_5, grid);
        scroll_txt_signature = new javax.swing.JScrollPane();
        scroll_txt_signature.setPreferredSize(new java.awt.Dimension(600, 56));
        txt_signature = new javax.swing.JTextArea();
        txt_signature.setLineWrap(true);
        txt_signature.setRows(2);
        txt_signature.setColumns(40);
        txt_signature.setEditable(true);
        txt_signature.setFont(new java.awt.Font("Segoe UI", 0, 12));
        scroll_txt_signature.setViewportView(txt_signature);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 5;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 1.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(scroll_txt_signature, grid);
        panel_actions = new javax.swing.JPanel();
        panel_actions.setBackground(new java.awt.Color(214, 217, 223));
        panel_actions.setLayout(new java.awt.GridBagLayout());
        btn_sign = new javax.swing.JButton();
        btn_sign.setText("Sign");
        btn_sign.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_sign.setPreferredSize(new java.awt.Dimension(110, 30));
        btn_sign.addActionListener(evt -> btn_signActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 0;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 0, 0);
        panel_actions.add(btn_sign, grid);
        btn_verify = new javax.swing.JButton();
        btn_verify.setText("Verify");
        btn_verify.setFont(new java.awt.Font("Segoe UI", 0, 12));
        btn_verify.setPreferredSize(new java.awt.Dimension(110, 30));
        btn_verify.addActionListener(evt -> btn_verifyActionPerformed(evt));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(btn_verify, grid);
        lbl_result = new javax.swing.JLabel();
        lbl_result.setText("");
        lbl_result.setFont(new java.awt.Font("Segoe UI", 1, 20));
        lbl_result.setPreferredSize(new java.awt.Dimension(300, 38));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 2;
        grid.gridy = 0;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 10, 0, 0);
        panel_actions.add(lbl_result, grid);
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 6;
        grid.gridwidth = 1;
        grid.fill = 0;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 12, 20);
        panel_main.add(panel_actions, grid);
        lbl_status = new javax.swing.JLabel();
        lbl_status.setText("Bấm Generate Keys hoặc Load Keys.");
        lbl_status.setFont(new java.awt.Font("Segoe UI", 0, 12));
        lbl_status.setPreferredSize(new java.awt.Dimension(600, 36));
        grid = new java.awt.GridBagConstraints();
        grid.gridx = 1;
        grid.gridy = 7;
        grid.gridwidth = 1;
        grid.fill = 2;
        grid.anchor = 18;
        grid.weightx = 0.0;
        grid.weighty = 0.0;
        grid.insets = new java.awt.Insets(0, 0, 14, 20);
        panel_main.add(lbl_status, grid);
        getContentPane().add(panel_main, java.awt.BorderLayout.CENTER);
        pack();
    }
    private void btn_generateActionPerformed(java.awt.event.ActionEvent evt) {
        runAsync(() -> {
            cipher.generateKeys();
            return new String[]{cipher.getPublicKeyBase64(), cipher.getPrivateKeyBase64()};
        }, keys -> {
            showKeys(keys);
            lbl_status.setText("Đã tạo cặp khóa mới.");
        });
    }
    private void btn_savekeysActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            String content = CryptoSupport.toKeyFile(txt_public.getText(), txt_private.getText());
            String path = FileTextIO.saveString(this, content, "ecdsa_keys.txt");
            if (path != null) lbl_status.setText("Đã lưu khóa vào: " + path);
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }
    private void btn_loadkeysActionPerformed(java.awt.event.ActionEvent evt) {
        String content = FileTextIO.openString(this);
        if (content == null) return;
        runAsync(() -> {
            String[] keys = CryptoSupport.fromKeyFile(content);
            cipher.loadKeys(keys[0], keys[1]);
            return new String[]{cipher.getPublicKeyBase64(), cipher.getPrivateKeyBase64()};
        }, keys -> {
            showKeys(keys);
            lbl_status.setText("Đã nạp khóa từ tệp.");
        });
    }
    private void btn_signActionPerformed(java.awt.event.ActionEvent evt) {
        String message = txt_message.getText();
        lbl_result.setText("");
        executeOperation(() -> cipher.sign(message), "ECDSA", "SIGN", message.length(), output -> {
            txt_signature.setText(output);
            txt_signature.setCaretPosition(0);
        });
    }
    private void btn_verifyActionPerformed(java.awt.event.ActionEvent evt) {
        String message = txt_message.getText();
        String signature = txt_signature.getText();
        lbl_result.setText("");
        executeOperation(() -> cipher.verify(message, signature) ? "VALID" : "INVALID", "ECDSA", "VERIFY", message.length(), output -> {
            lbl_result.setText(output);
            lbl_result.setForeground(output.equals("VALID") ? new java.awt.Color(0, 128, 0) : java.awt.Color.RED);
        });
    }
    private boolean processing;
    private void showError(String text) {
        lbl_status.setText("<html>" + text + "</html>");
        javax.swing.JOptionPane.showMessageDialog(this, text, "Thông báo", javax.swing.JOptionPane.ERROR_MESSAGE);
    }
    private void enableInputs(java.awt.Container container, boolean enabled) {
        for (java.awt.Component component : container.getComponents()) {
            if (component instanceof javax.swing.JButton || component instanceof javax.swing.JComboBox
                    || component instanceof javax.swing.text.JTextComponent) component.setEnabled(enabled);
            if (component instanceof java.awt.Container child) enableInputs(child, enabled);
        }
    }
    private <T> void runAsync(java.util.concurrent.Callable<T> task, java.util.function.Consumer<T> completed) {
        if (processing) return;
        processing = true;
        enableInputs(panel_main, false);
        lbl_status.setText("Đang xử lý...");
        new javax.swing.SwingWorker<T, Void>() {
            protected T doInBackground() throws Exception {
                return task.call();
            }
            protected void done() {
                try {
                    completed.accept(get());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                    showError("Thao tác đã bị gián đoạn.");
                } catch (java.util.concurrent.ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    showError(cause.getMessage() == null ? "Không thực hiện được thao tác." : cause.getMessage());
                } finally {
                    processing = false;
                    enableInputs(panel_main, true);
                }
            }
        }.execute();
    }
    private record OperationResult(String output, String error, String history) {
    }
    private void executeOperation(java.util.concurrent.Callable<String> task, String algorithm, String operation,
            int length, java.util.function.Consumer<String> completed) {
        runAsync(() -> {
            try {
                String output = task.call();
                boolean success = !operation.equals("VERIFY") || output.equals("VALID");
                return new OperationResult(output, null, Tuan3.Dulieu.LichSu.tryInsert(algorithm, operation, length, success));
            } catch (Exception ex) {
                String error = ex instanceof javax.crypto.AEADBadTagException || ex instanceof javax.crypto.BadPaddingException
                        ? "Giải mã THẤT BẠI: sai khóa riêng hoặc bản mã bị sửa."
                        : ex.getMessage() == null ? "Thao tác THẤT BẠI." : ex.getMessage();
                return new OperationResult(null, error, Tuan3.Dulieu.LichSu.tryInsert(algorithm, operation, length, false));
            }
        }, result -> {
            if (result.error() != null) {
                showError(result.error() + " " + result.history());
            } else {
                completed.accept(result.output());
                lbl_status.setText("<html>Đã thực hiện " + algorithm + " / " + operation + ". " + result.history() + "</html>");
            }
        });
    }
    private final SignatureEngine cipher = new SignatureEngine();
    public static final class SignatureEngine {
        private volatile java.security.KeyPair keys;
        public void generateKeys() throws Exception {
            keys = CryptoSupport.newEc();
        }
        public String getPublicKeyBase64() {
            return keys == null ? "" : CryptoSupport.b64(keys.getPublic().getEncoded());
        }
        public String getPrivateKeyBase64() {
            return keys == null || keys.getPrivate() == null ? "" : CryptoSupport.b64(keys.getPrivate().getEncoded());
        }
        public void loadKeys(String publicText, String privateText) throws Exception {
            keys = CryptoSupport.readEcKeys(publicText, privateText);
        }
        public String sign(String message) throws Exception {
            java.security.KeyPair current = keys;
            if (current == null || current.getPrivate() == null) throw new IllegalStateException("Chưa có khóa riêng: bấm Generate Keys hoặc Load Keys.");
            var signature = java.security.Signature.getInstance("SHA256withECDSA");
            signature.initSign(current.getPrivate());
            signature.update(CryptoSupport.utf8(message));
            return CryptoSupport.b64(signature.sign());
        }
        public boolean verify(String message, String encoded) throws Exception {
            java.security.KeyPair current = keys;
            if (current == null) throw new IllegalStateException("Chưa có khóa công khai.");
            var signature = java.security.Signature.getInstance("SHA256withECDSA");
            signature.initVerify(current.getPublic());
            signature.update(CryptoSupport.utf8(message));
            byte[] data = CryptoSupport.unb64(encoded);
            try {
                return signature.verify(data);
            } catch (java.security.SignatureException ex) {
                return false;
            }
        }
    }
    private void showKeys(String[] keys) {
        txt_public.setText(keys[0]);
        txt_private.setText(keys[1]);
        txt_public.setCaretPosition(0);
        txt_private.setCaretPosition(0);
    }
    public static void main(String[] args) {
        try {
            javax.swing.UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception ex) {
            java.awt.Toolkit.getDefaultToolkit().beep();
        }
        java.awt.EventQueue.invokeLater(() -> new bai1nangcao().setVisible(true));
    }
    private javax.swing.JPanel panel_main;
    private javax.swing.JLabel lbl_title;
    private javax.swing.JLabel lbl_1;
    private javax.swing.JScrollPane scroll_txt_public;
    private javax.swing.JTextArea txt_public;
    private javax.swing.JLabel lbl_2;
    private javax.swing.JScrollPane scroll_txt_private;
    private javax.swing.JTextArea txt_private;
    private javax.swing.JPanel panel_keys;
    private javax.swing.JButton btn_generate;
    private javax.swing.JButton btn_savekeys;
    private javax.swing.JButton btn_loadkeys;
    private javax.swing.JLabel lbl_4;
    private javax.swing.JScrollPane scroll_txt_message;
    private javax.swing.JTextArea txt_message;
    private javax.swing.JLabel lbl_5;
    private javax.swing.JScrollPane scroll_txt_signature;
    private javax.swing.JTextArea txt_signature;
    private javax.swing.JPanel panel_actions;
    private javax.swing.JButton btn_sign;
    private javax.swing.JButton btn_verify;
    private javax.swing.JLabel lbl_result;
    private javax.swing.JLabel lbl_status;
}
